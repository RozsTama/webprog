<h2>Galéria</h2>
<?php
arsort($kepek);
foreach ($kepek as $fajl => $datum) { ?>
    <div class="kep">
        <a href="<?= $galeria['konyvtar'] . $fajl ?>">
            <img src="<?= $galeria['konyvtar'] . $fajl ?>">
        </a>
    </div>
<?php } ?>
