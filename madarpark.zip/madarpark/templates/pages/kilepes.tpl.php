<h2>Kijelentkezett:</h2>
<?= $data['csaladnev'] . ' ' . $data['utonev'] . ' (' . $data['felhasznalonev'] . ')' ?>
