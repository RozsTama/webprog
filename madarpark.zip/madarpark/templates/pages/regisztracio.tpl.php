<?php   if (isset($uzenet)) { ?>
            <h2><?= $uzenet ?></h2>
<?php       if ($ujra) { ?>
            <a href="<?= $gyokerkonyvtar ?>belepes">Próbálja újra!</a>
<?php       } ?>
<?php   } ?>
