<blockquote>Nem rendelkezik az oldal megtekintéséhez szükséges jogosultsággal.</blockquote>
