<?php
if (isset($_SESSION['felhasznalonev'])) {
    header('Location: ' . $gyokerkonyvtar);
}
?>
